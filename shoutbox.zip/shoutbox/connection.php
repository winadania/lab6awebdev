<?php
// Create connection
$link = mysqli_connect('localhost', 'root', '',
'shoutbox');
?>