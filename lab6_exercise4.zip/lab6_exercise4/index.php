<?php include("auth.php"); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Welcome Home</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
    <p>Welcome <?php echo $_SESSION['username']; ?>!</p>
    <p>This is a secured area.</p>
    <p><a href="dashboard.php">Dashboard</a></p>
    <p><a href="logout.php">Logout</a></p>
</div>
</body>
</html>
